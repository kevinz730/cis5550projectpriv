cd /Users/KevinZhang/Desktop/CIS555/cis5550projectpriv/HW9; java -cp bin:lib/webserver.jar:lib/kvs.jar:lib/flame.jar cis5550.flame.Worker 9001 localhost:9000
