cd /Users/KevinZhang/Desktop/CIS555/cis5550projectpriv/HW9; java -cp bin:lib/webserver.jar:lib/kvs.jar cis5550.kvs.Worker 8001 worker1 localhost:8000
